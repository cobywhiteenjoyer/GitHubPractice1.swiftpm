import SwiftUI

struct NewPage: View {
    var body: some View {
        VStack {
            Text("new page")
        }
    }
}
