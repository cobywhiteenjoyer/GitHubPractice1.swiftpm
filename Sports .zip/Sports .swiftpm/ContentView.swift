import SwiftUI

struct ContentView: View {
    var body: some View {
        NavigationStack {
            NavigationLink("Other Sports") {
                NewPage()
            }
        }
        Text("Playbook Chicago")
            .font(.title)
        Text("Top Headlines")
            .font(.headline)
        Divider()
        HStack {
            Text("Colston Loveland goes 10 to Chicago!\n The Chicago football world is going crazy as Colston Loveland, the 10th pick of the most recent draft is heading to Chi Town")
                .font(.system(size: 15))
            Divider()
            Text("Chicago pitcher out for longer!")
                .font(.system(size: 15))
        }
        Divider()
        HStack {
            Text("Miami beats Chicago-season over")
                .font(.system(size: 15))
            Divider()
            Text("Chicago beats Los Angeles in thriller")
                .font(.system(size: 15))
        }
    }
}
